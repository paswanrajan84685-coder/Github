export interface Formula {
  id: string;
  title: string;
  latex: string;
  description?: string;
}

export interface Chapter {
  id: string;
  title: string;
  icon: string;
  formulas: Formula[];
}

export const formulaData: Chapter[] = [
  {
    id: "real-numbers",
    title: "Real Numbers",
    icon: "Hash",
    formulas: [
      {
        id: "euclid-division-lemma",
        title: "Euclid's Division Lemma",
        latex: "a = bq + r, \\quad 0 \\le r < b",
        description: "Given positive integers a and b, there exist unique integers q and r satisfying this condition."
      },
      {
        id: "fundamental-theorem-arithmetic",
        title: "Fundamental Theorem of Arithmetic",
        latex: "HCF(a, b) \\times LCM(a, b) = a \\times b",
        description: "The product of HCF and LCM of two numbers is equal to the product of the numbers."
      }
    ]
  },
  {
    id: "polynomials",
    title: "Polynomials",
    icon: "FunctionSquare",
    formulas: [
      {
        id: "quadratic-poly-zeros",
        title: "Relationship between Zeros and Coefficients (Quadratic)",
        latex: "\\alpha + \\beta = -\\frac{b}{a}, \\quad \\alpha\\beta = \\frac{c}{a}",
        description: "For a quadratic polynomial ax^2 + bx + c, where α and β are zeros."
      },
      {
        id: "cubic-poly-zeros",
        title: "Relationship between Zeros and Coefficients (Cubic)",
        latex: "\\alpha + \\beta + \\gamma = -\\frac{b}{a}, \\quad \\alpha\\beta + \\beta\\gamma + \\gamma\\alpha = \\frac{c}{a}, \\quad \\alpha\\beta\\gamma = -\\frac{d}{a}",
        description: "For a cubic polynomial ax^3 + bx^2 + cx + d."
      }
    ]
  },
  {
    id: "linear-equations",
    title: "Pair of Linear Equations",
    icon: "Rows",
    formulas: [
      {
        id: "condition-consistency",
        title: "Conditions for Consistency",
        latex: "\\begin{cases} \\frac{a_1}{a_2} \\ne \\frac{b_1}{b_2} & \\text{Unique Solution} \\\\ \\frac{a_1}{a_2} = \\frac{b_1}{b_2} = \\frac{c_1}{c_2} & \\text{Infinitely Many} \\\\ \\frac{a_1}{a_2} = \\frac{b_1}{b_2} \\ne \\frac{c_1}{c_2} & \\text{No Solution} \\end{cases}",
        description: "For two linear equations a₁x + b₁y + c₁ = 0 and a₂x + b₂y + c₂ = 0."
      }
    ]
  },
  {
    id: "quadratic-equations",
    title: "Quadratic Equations",
    icon: "Square",
    formulas: [
      {
        id: "quadratic-formula",
        title: "Quadratic Formula",
        latex: "x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}",
        description: "Roots of ax^2 + bx + c = 0."
      },
      {
        id: "discriminant",
        title: "Discriminant (D)",
        latex: "D = b^2 - 4ac",
        description: "D > 0: Real & Distinct, D = 0: Real & Equal, D < 0: No Real Roots."
      }
    ]
  },
  {
    id: "arithmetic-progressions",
    title: "Arithmetic Progressions",
    icon: "TrendingUp",
    formulas: [
      {
        id: "nth-term-ap",
        title: "n-th Term of an AP",
        latex: "a_n = a + (n-1)d",
        description: "Where 'a' is the first term and 'd' is the common difference."
      },
      {
        id: "sum-n-terms-ap",
        title: "Sum of First n Terms",
        latex: "S_n = \\frac{n}{2}[2a + (n-1)d] = \\frac{n}{2}(a + l)",
        description: "Where 'l' is the last term."
      },
      {
        id: "arithmetic-mean",
        title: "Arithmetic Mean",
        latex: "AM = \\frac{a+b}{2}",
        description: "If a, b, c are in AP, then b is the AM of a and c."
      }
    ]
  },
  {
    id: "triangles",
    title: "Triangles",
    icon: "Triangle",
    formulas: [
      {
        id: "bpt",
        title: "Basic Proportionality Theorem (Thales)",
        latex: "\\frac{AD}{DB} = \\frac{AE}{EC}",
        description: "If a line is parallel to one side of a triangle intersecting other two sides, it divides them in the same ratio."
      },
      {
        id: "pythagoras",
        title: "Pythagoras Theorem",
        latex: "AC^2 = AB^2 + BC^2",
        description: "In a right-angled triangle ABC (right-angled at B)."
      }
    ]
  },
  {
    id: "coordinate-geometry",
    title: "Coordinate Geometry",
    icon: "Map",
    formulas: [
      {
        id: "distance-formula",
        title: "Distance Formula",
        latex: "d = \\sqrt{(x_2-x_1)^2 + (y_2-y_1)^2}",
        description: "Distance between P(x1, y1) and Q(x2, y2)."
      },
      {
        id: "section-formula",
        title: "Section Formula (Internal)",
        latex: "P(x, y) = \\left( \\frac{mx_2 + nx_1}{m+n}, \\frac{my_2 + ny_1}{m+n} \\right)",
        description: "P divides the line segment AB in ratio m:n."
      },
      {
        id: "midpoint-formula",
        title: "Midpoint Formula",
        latex: "M(x, y) = \\left( \\frac{x_1 + x_2}{2}, \\frac{y_1 + y_2}{2} \\right)",
        description: "Midpoint of AB."
      },
      {
        id: "area-triangle-coord",
        title: "Area of Triangle",
        latex: "\\text{Area} = \\frac{1}{2} |x_1(y_2-y_3) + x_2(y_3-y_1) + x_3(y_1-y_2)|",
        description: "Area with vertices (x1,y1), (x2,y2), (x3,y3)."
      }
    ]
  },
  {
    id: "trigonometry",
    title: "Trigonometry",
    icon: "Waves",
    formulas: [
      {
        id: "trig-ratios",
        title: "Trigonometric Ratios",
        latex: "\\sin \\theta = \\frac{P}{H}, \\cos \\theta = \\frac{B}{H}, \\tan \\theta = \\frac{P}{B}",
        description: "P = Perpendicular, B = Base, H = Hypotenuse."
      },
      {
        id: "trig-identities",
        title: "Trigonometric Identities",
        latex: "\\begin{gather} \\sin^2 \\theta + \\cos^2 \\theta = 1 \\\\ 1 + \\tan^2 \\theta = \\sec^2 \\theta \\\\ 1 + \\cot^2 \\theta = \\csc^2 \\theta \\end{gather}",
        description: "Standard fundamental identities."
      },
      {
        id: "complementary-angles",
        title: "Trigonometric Ratios of Complementary Angles",
        latex: "\\begin{gather} \\sin(90^\\circ - \\theta) = \\cos \\theta \\\\ \\tan(90^\\circ - \\theta) = \\cot \\theta \\\\ \\sec(90^\\circ - \\theta) = \\csc \\theta \\end{gather}",
        description: "Note: These may be removed from some syllabi but are still useful."
      },
      {
        id: "standard-angles",
        title: "Standard Angle Values",
        latex: "\\begin{array}{|c|c|c|c|c|c|} \\hline \\theta & 0^\\circ & 30^\\circ & 45^\\circ & 60^\\circ & 90^\\circ \\\\ \\hline \\sin & 0 & 1/2 & 1/\\sqrt{2} & \\sqrt{3}/2 & 1 \\\\ \\hline \\cos & 1 & \\sqrt{3}/2 & 1/\\sqrt{2} & 1/2 & 0 \\\\ \\hline \\tan & 0 & 1/\\sqrt{3} & 1 & \\sqrt{3} & \\infty \\\\ \\hline \\end{array}",
        description: "Quick reference for common trigonometric values."
      }
    ]
  },
  {
    id: "applications-trig",
    title: "Applications of Trigonometry",
    icon: "TrendingUp",
    formulas: [
      {
        id: "height-dist",
        title: "Height and Distance",
        latex: "\\tan \\theta = \\frac{\\text{Height (opposite)}}{\\text{Distance (adjacent)}}",
        description: "Fundamental relation used to find heights and distances using angle of elevation/depression."
      }
    ]
  },
  {
    id: "circles",
    title: "Circles",
    icon: "Circle",
    formulas: [
      {
        id: "tangent-property",
        title: "Tangent Property",
        latex: "\\text{Tangent } \\perp \\text{ Radius}",
        description: "The tangent at any point of a circle is perpendicular to the radius through the point of contact."
      },
      {
        id: "tangents-external",
        title: "Tangents from External Point",
        latex: "PA = PB",
        description: "Lengths of tangents drawn from an external point to a circle are equal."
      }
    ]
  },
  {
    id: "area-related-circles",
    title: "Areas Related to Circles",
    icon: "PieChart",
    formulas: [
      {
        id: "circle-circum-area",
        title: "Circumference and Area",
        latex: "C = 2\\pi r, \\quad A = \\pi r^2",
        description: "r is the radius of the circle."
      },
      {
        id: "sector-area",
        title: "Area of Sector",
        latex: "\\text{Area} = \\frac{\\theta}{360^\\circ} \\times \\pi r^2",
        description: "θ is the angle of the sector."
      },
      {
        id: "arc-length",
        title: "Length of an Arc",
        latex: "l = \\frac{\\theta}{360^\\circ} \\times 2\\pi r",
        description: "Length of arc subtending angle θ at center."
      }
    ]
  },
  {
    id: "surface-area-volumes",
    title: "Surface Areas & Volumes",
    icon: "Box",
    formulas: [
      {
        id: "cuboid",
        title: "Cuboid",
        latex: "V = lwh, \\quad TSA = 2(lw + wh + hl), \\quad d = \\sqrt{l^2 + w^2 + h^2}",
        description: "l=length, w=width, h=height, d=diagonal."
      },
      {
        id: "cube",
        title: "Cube",
        latex: "V = a^3, \\quad TSA = 6a^2, \\quad d = a\\sqrt{3}",
        description: "a is the edge length."
      },
      {
        id: "cylinder",
        title: "Cylinder",
        latex: "V = \\pi r^2h, \\quad CSA = 2\\pi rh, \\quad TSA = 2\\pi r(r+h)",
        description: "CSA = Curved Surface Area, TSA = Total Surface Area."
      },
      {
        id: "cone",
        title: "Cone",
        latex: "V = \\frac{1}{3}\\pi r^2h, \\quad CSA = \\pi rl, \\quad l = \\sqrt{r^2 + h^2}",
        description: "l is the slant height."
      },
      {
        id: "sphere",
        title: "Sphere",
        latex: "V = \\frac{4}{3}\\pi r^3, \\quad SA = 4\\pi r^2",
        description: "Volume and Surface Area of a sphere."
      },
      {
        id: "hemisphere",
        title: "Hemisphere",
        latex: "V = \\frac{2}{3}\\pi r^3, \\quad CSA = 2\\pi r^2, \\quad TSA = 3\\pi r^2",
        description: "Volume and Surface Areas of a hemisphere."
      },
      {
        id: "frustum",
        title: "Frustum of a Cone",
        latex: "\\begin{gather} V = \\frac{1}{3}\\pi h(r_1^2 + r_2^2 + r_1r_2) \\\\ CSA = \\pi(r_1 + r_2)l, \\quad l = \\sqrt{h^2 + (r_1-r_2)^2} \\end{gather}",
        description: "Note: Frustum is often removed/added in different syllabus cycles."
      }
    ]
  },
  {
    id: "statistics",
    title: "Statistics",
    icon: "BarChart3",
    formulas: [
      {
        id: "mean-direct",
        title: "Mean (Direct Method)",
        latex: "\\bar{x} = \\frac{\\sum f_i x_i}{\\sum f_i}",
        description: "Standard method for calculating average."
      },
      {
        id: "mean-assumed",
        title: "Mean (Assumed Mean Method)",
        latex: "\\bar{x} = a + \\frac{\\sum f_i d_i}{\\sum f_i}",
        description: "a = assumed mean, d_i = x_i - a."
      },
      {
        id: "mean-step-deviation",
        title: "Mean (Step-Deviation Method)",
        latex: "\\bar{x} = a + h \\left( \\frac{\\sum f_i u_i}{\\sum f_i} \\right)",
        description: "h = class size, u_i = (x_i - a) / h."
      },
      {
        id: "mode",
        title: "Mode",
        latex: "l + \\left( \\frac{f_1 - f_0}{2f_1 - f_0 - f_2} \\right) \\times h",
        description: "l=lower limit of modal class, h=size of class interval, f1=freq of modal class, f0=freq of preceding class, f2=freq of succeeding class."
      },
      {
        id: "median",
        title: "Median",
        latex: "l + \\left( \\frac{\\frac{n}{2} - cf}{f} \\right) \\times h",
        description: "l=lower limit of median class, n=number of observations, cf=cumulative freq of preceding class, f=freq of median class."
      },
      {
        id: "empirical-rel",
        title: "Empirical Relationship",
        latex: "3 \\times \\text{Median} = \\text{Mode} + 2 \\times \\text{Mean}",
        description: "Relates the three measures of central tendency."
      }
    ]
  },
  {
    id: "probability",
    title: "Probability",
    icon: "Dices",
    formulas: [
      {
        id: "prob-event",
        title: "Probability of an Event",
        latex: "P(E) = \\frac{\\text{No. of outcomes favorable to E}}{\\text{Total no. of outcomes}}",
        description: "0 \\le P(E) \\le 1."
      },
      {
        id: "complementary-event",
        title: "Complementary Event",
        latex: "P(E) + P(\\bar{E}) = 1",
        description: "P(not E) = 1 - P(E)."
      }
    ]
  }
];
