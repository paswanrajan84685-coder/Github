import React, { useState, useMemo } from 'react';
import 'katex/dist/katex.min.css';
import { InlineMath, BlockMath } from 'react-katex';
import { 
  Search, 
  Menu, 
  X, 
  Hash, 
  FunctionSquare, 
  Rows, 
  Square, 
  TrendingUp, 
  Triangle, 
  Map as MapIcon, 
  Waves, 
  Circle, 
  PieChart, 
  Box, 
  BarChart3, 
  Dices,
  ChevronRight,
  Calculator
} from 'lucide-react';
import { formulaData } from './data/formulas';

const iconMap: Record<string, React.ReactNode> = {
  Hash: <Hash className="w-5 h-5" />,
  FunctionSquare: <FunctionSquare className="w-5 h-5" />,
  Rows: <Rows className="w-5 h-5" />,
  Square: <Square className="w-5 h-5" />,
  TrendingUp: <TrendingUp className="w-5 h-5" />,
  Triangle: <Triangle className="w-5 h-5" />,
  Map: <MapIcon className="w-5 h-5" />,
  Waves: <Waves className="w-5 h-5" />,
  Circle: <Circle className="w-5 h-5" />,
  PieChart: <PieChart className="w-5 h-5" />,
  Box: <Box className="w-5 h-5" />,
  BarChart3: <BarChart3 className="w-5 h-5" />,
  Dices: <Dices className="w-5 h-5" />
};

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedChapter, setSelectedChapter] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const filteredData = useMemo(() => {
    if (!searchTerm) return formulaData;
    
    return formulaData.map(chapter => ({
      ...chapter,
      formulas: chapter.formulas.filter(formula => 
        formula.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        formula.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        chapter.title.toLowerCase().includes(searchTerm.toLowerCase())
      )
    })).filter(chapter => chapter.formulas.length > 0);
  }, [searchTerm]);

  const displayedChapters = selectedChapter 
    ? filteredData.filter(c => c.id === selectedChapter)
    : filteredData;

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button 
            onClick={toggleSidebar}
            className="p-2 hover:bg-slate-100 rounded-lg lg:hidden"
          >
            <Menu className="w-6 h-6 text-slate-600" />
          </button>
          <div className="flex items-center gap-2">
            <div className="bg-indigo-600 p-2 rounded-lg text-white">
              <Calculator className="w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold text-slate-800 hidden sm:block">MathDocs <span className="text-indigo-600">Class 10</span></h1>
          </div>
        </div>

        <div className="flex-1 max-w-md mx-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search formulas (e.g. Pythagoras, Mean...)"
              className="w-full pl-10 pr-4 py-2 bg-slate-100 border-transparent focus:bg-white focus:ring-2 focus:ring-indigo-500 rounded-full text-sm outline-none transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="hidden md:block">
          <a 
            href="https://github.com" 
            target="_blank" 
            rel="noreferrer"
            className="text-sm font-medium text-slate-600 hover:text-indigo-600 transition-colors"
          >
            Quick Reference Guide
          </a>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className={`
          fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-slate-200 transform transition-transform duration-200 ease-in-out lg:relative lg:translate-x-0
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}>
          <div className="h-full flex flex-col">
            <div className="p-4 lg:hidden flex justify-between items-center border-b">
              <span className="font-bold text-slate-800 uppercase text-xs tracking-wider">Chapters</span>
              <button onClick={toggleSidebar}>
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>
            
            <nav className="flex-1 overflow-y-auto p-4 space-y-1">
              <button
                onClick={() => {
                  setSelectedChapter(null);
                  setIsSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  selectedChapter === null 
                  ? 'bg-indigo-50 text-indigo-700' 
                  : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <div className="w-5 h-5 flex items-center justify-center">🏠</div>
                All Chapters
              </button>
              
              <div className="pt-4 pb-2 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                Chapter List
              </div>
              
              {formulaData.map((chapter) => (
                <button
                  key={chapter.id}
                  onClick={() => {
                    setSelectedChapter(chapter.id);
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    selectedChapter === chapter.id 
                    ? 'bg-indigo-50 text-indigo-700' 
                    : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={selectedChapter === chapter.id ? 'text-indigo-600' : 'text-slate-400'}>
                      {iconMap[chapter.icon]}
                    </span>
                    <span className="truncate">{chapter.title}</span>
                  </div>
                  {selectedChapter === chapter.id && <ChevronRight className="w-4 h-4" />}
                </button>
              ))}
            </nav>
            
            <div className="p-4 border-t border-slate-100">
              <div className="bg-indigo-600 rounded-xl p-4 text-white">
                <p className="text-xs font-semibold opacity-80 mb-1">Study Tip</p>
                <p className="text-sm">Practice derivation of formulas for better retention!</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-12 scroll-smooth">
          <div className="max-w-4xl mx-auto">
            {displayedChapters.length === 0 ? (
              <div className="text-center py-20">
                <div className="bg-slate-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-800">No formulas found</h3>
                <p className="text-slate-500">Try adjusting your search terms.</p>
              </div>
            ) : (
              displayedChapters.map((chapter) => (
                <section key={chapter.id} className="mb-12 last:mb-0 scroll-mt-24" id={chapter.id}>
                  <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg">
                      {iconMap[chapter.icon]}
                    </div>
                    <h2 className="text-2xl font-bold text-slate-800">{chapter.title}</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {chapter.formulas.map((formula) => (
                      <div 
                        key={formula.id}
                        className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow group"
                      >
                        <h3 className="text-lg font-bold text-slate-800 mb-3 group-hover:text-indigo-600 transition-colors">
                          {formula.title}
                        </h3>
                        <div className="bg-slate-50 rounded-xl p-4 mb-4 overflow-x-auto min-h-[80px] flex items-center justify-center">
                          <div className="text-xl text-slate-700">
                            {formula.latex.includes('\\\\') || formula.latex.includes('\\begin') ? (
                                <BlockMath math={formula.latex} />
                            ) : (
                                <InlineMath math={formula.latex} />
                            )}
                          </div>
                        </div>
                        {formula.description && (
                          <p className="text-sm text-slate-500 leading-relaxed">
                            {formula.description}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </section>
              ))
            )}
          </div>
          
          <footer className="max-w-4xl mx-auto mt-20 pt-8 border-t border-slate-200 pb-12 text-center text-slate-400 text-sm">
            <p>© {new Date().getFullYear()} Class 10 Maths Formula Guide. Designed for Students.</p>
          </footer>
        </main>
      </div>

      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-30 lg:hidden backdrop-blur-sm"
          onClick={toggleSidebar}
        />
      )}
    </div>
  );
}

export default App;
